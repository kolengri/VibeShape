# VibeShape SolveSpace corresponding source

This bundle records the exact SolveSpace v3.2, Eigen, and mimalloc source archives, project patch, typed-array ABI wrapper, local build recipe, licenses, and evidence used by VibeShape.

The build is intentionally local-only. Mount this directory at `/input:ro`, an empty output directory at `/output`, and run `bash /input/build/build.sh` in `emscripten/emsdk@sha256:1107465ce37d6d95942e53774ef2d272bea3880bb07d37fe63213469ef2d05dc` on `linux/arm64`. The source archives must be available under `/input/sources` with the filenames used in this bundle.
